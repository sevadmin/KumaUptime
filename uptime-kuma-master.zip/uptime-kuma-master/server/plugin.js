class Plugin {
    async load() {

    }

    async unload() {

    }
}

module.exports = {
    Plugin,
};
